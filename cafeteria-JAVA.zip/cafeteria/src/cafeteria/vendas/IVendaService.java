package cafeteria.vendas;

public interface IVendaService {
    void registrarVenda(Venda venda);
}
